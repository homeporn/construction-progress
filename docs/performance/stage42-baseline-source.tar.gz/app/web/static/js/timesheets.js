(function () {
  'use strict';
  var editor = document.querySelector('#cell-editor form');
  if (editor) {
    document.querySelectorAll('.ts-cell').forEach(function (button) {
      button.addEventListener('click', function () {
        editor.elements.employee_id.value = button.dataset.employee;
        editor.elements.work_date.value = button.dataset.date;
        editor.elements.code.value = button.dataset.code || 'Я';
        editor.elements.hours.value = button.dataset.hours || '';
        editor.elements.comment.value = button.dataset.comment || '';
        document.getElementById('cell-editor').scrollIntoView({ block: 'center', behavior: 'smooth' });
        editor.elements.hours.focus({ preventScroll: true });
      });
    });
  }
  document.querySelectorAll('[data-select-employees]').forEach(function (button) {
    button.addEventListener('click', function () {
      button.closest('form').querySelectorAll('input[name="employee_id"]').forEach(function (input) {
        input.checked = true;
      });
    });
  });
  var dirty = false;
  document.querySelectorAll('[data-unsaved-warning]').forEach(function (form) {
    form.addEventListener('change', function () { dirty = true; });
    form.addEventListener('input', function () { dirty = true; });
  });
  document.querySelectorAll('form').forEach(function (form) {
    form.addEventListener('submit', function () { dirty = false; });
  });
  window.addEventListener('beforeunload', function (event) {
    if (dirty) { event.preventDefault(); event.returnValue = ''; }
  });
}());
