"""Transactional SQLite repositories."""
